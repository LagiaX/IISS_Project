import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

// Import rxjs map operator
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app works!';

  // Link to our api, pointing to localhost
  API = 'http://localhost:3000';

  // Declare empty list of people
  people: any[] = [];

  constructor(private http: Http) {}

  // Angular 2 Life Cycle event when component has been initialized
  ngOnInit() {
    this.getAllPeople();
  }

  // Add one person to the API
  addPerson(DNI, firstname, lastname, license) {
    this.http.post(`${this.API}/users`, {DNI, firstname, lastname, license})
      .map(res => res.json())
      .subscribe(() => {
        this.getAllPeople();
      })
  }

  // Get all users from the API
  getAllPeople() {
    this.http.get(`${this.API}/users`)
      .map(res => res.json())
      .subscribe(people => {
        console.log(people)
        this.people = people
      })
  }
/*
  removePerson(user){
    this.http.get(`${this.API}/deleteuser/#{user._DNI}`)
    .map(res => res.json())
    .subscribe(() => {
      this.getAllPeople();
    })
  }*/
  removePerson(dni){
    this.people = this.people.filter(people => people.DNI !== dni);
    this.getAllPeople();
  }
}
