// Import dependencies
const mongoose = require('mongoose');
const express = require('express');
const router = express.Router();

// MongoDB URL from the docker-compose file
const dbHost = 'mongodb://database/mean-docker';

// Connect to mongodb
mongoose.connect(dbHost);

// create mongoose schema
const userSchema = new mongoose.Schema({
  DNI: String,
  firstname: String,
  lastname: String,
  license: Boolean
});

// create mongoose model
const User = mongoose.model('User', userSchema);

/* GET api listing. */
router.get('/', (req, res) => {
        res.send('api works, jurame ezo..');
});

/* GET all users. */
router.get('/users', (req, res) => {
    User.find({}, (err, users) => {
        if (err) res.status(500).send(error)

        res.status(200).json(users);
    });
});

/* GET one users. */
router.get('/users/:id', (req, res) => {
    User.findById(req.param.DNI, (err, users) => {
        if (err) res.status(500).send(error)

        res.status(200).json(users);
    });
});

/* Create a user. */
router.post('/users', (req, res) => {
    let user = new User({
        DNI: req.body.DNI,
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        license: req.body.license
    });

    user.save(error => {
        if (error) res.status(500).send(error);

        res.status(201).json({
            message: 'User created successfully'
        });
    });
});

////////FUNCIONES ANHADIDAS LUEGO DEL TUTORIAL
/*
router.post('/delete_user', (req, res) => {
     User.remove({
         DNI: req.params.DNI,
         firstname: req.params.firstname,
         lastname: req.params.lastname,
         license: req.params.license
     });
});*/
/*
// Delete user
router.get('/deleteuser/:DNI', function(req, res) { 

    var db = req.db;

    var uid = req.params.DNI.toString();
    var collection = db.get('usercollection');

    collection.remove({"_DNI":uid}, function(err, result) { 
        res.send( (result === 1) ? { msg: 'Deleted' } : { msg: 'error: '+ err } );
    });
*/
/*
app.delete('/user/:DNI', function(req, res){
  user.remove({_DNI: req.params.DNI}, function(err){ 
    if(err) res.json(err); 
  }); 
});
*/
/*
router.put('/edit_user', (req, res) => {
    User.findById(req.params.DNI, function (err, user) {
        if (err) res.send(err);

        if (req.body.DNI) user.DNI = req.body.DNI;
        if (req.body.firstname) user.firstname = req.body.firstname;
        if (req.body.lastname) user.lastname = req.body.lastname;
        if (req.body.license) user.license = req.body.license;

        user.save( function (err){
            if (err) send (err);
            res.json({message: 'User updated'});
    });
});
*/
module.exports = router;

